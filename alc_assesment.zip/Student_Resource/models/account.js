var mysql=require('mysql');
var express=require('express');
var fs=require('fs');
var app=require('express')();
var bodyParser=require('body-parser');
var path=require('path');
var flash = require('connect-flash');
//var mysql=require('mysql');
var morgan=require('morgan');

var con=mysql.createConnection({
  host: "localhost",
  user:"root",
  password: "",
  database: "student_resource"
});
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected");
});
app.set('view-engine', 'ejs');
// app.set('views', __dirname + '.././views/')
app.use(express.static(path.join(__dirname, '.././materialize')));
app.use(morgan('combined'));
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());
app.get('/', function(req, res) {
  // res.redirect('.././account.html');
    res.sendFile(path.join(__dirname, '.././account.html'));

  var sql=con.query("SELECT * FROM signup", function(err, results){
    if (results.length==0) {
       console.log("No Student Found!!!");
    } else {
      results= results;
      console.log(results);
        return res.render('.././views/account.ejs', {data: results});
     }
});
app.get('/delete/:id', function(req,res) {
  var id = req.params.id;
var sql=con.query("DELETE FROM signup WHERE id=?", [id], function(err) {
if (err) throw(err);
res.redirect('back');
// app.use(flash('success', {msg: 'Students was successful deleted'}));
// req.flash('success', {msg: 'Students was successful deleted'});
// res.locals.messages = req.flash();
console.log("Record Deleted");
// next();
});
});
app.get('/edit/:id', function(err,results) {
  res.render('.././views/edit.ejs', {data: results});

var sql=con.query("UPDATE signup SET fname=?, class=?, courses=?,", [fname, form , courses], function(err){
 if(err) throw(err);
 });
 });
});
app.listen(8080);
