var mysql=require('mysql');
var express=require('express');
var fs=require('fs');
var app=require('express')();
var bodyParser=require('body-parser');
var path=require('path');
var morgan=require('morgan');

var con=mysql.createConnection({
  host: "localhost",
  user:"root",
  password: "",
  database: "student_resource"
});
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected");
});
app.use(express.static(path.join(__dirname, '.././materialize')));
app.use(morgan('combined'));
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());
app.get('/', function(req, res, next) {
    res.sendFile(path.join(__dirname, '.././signup.html'));

var sql=con.query("SELECT * FROM signup ORDER BY id DESC", function(err, results){
  if (results.length==0) {
    // res.send("No Student Found!!!");
     console.log("No Student Found!!!");
  } else {
    results= results;
    // console.log(results);
  }

app.post('/account',function(req, res) {
  console.log(req.body.fname);
  console.log(req.body.class);
  console.log(req.body.courses);
  // console.log(req.body.id);
var sql=con.query("INSERT INTO signup (fname,class,courses) VALUES('"+req.body.fname+"','"+req.body.class+"','"+req.body.courses+"')");
console.log("Registration Successful");
return res.render('.././views/account.ejs', {data: results});
app.get('/delete/:id', function(req,res) {
  var id = results.id;
  console.log(id);
var sqll=con.query("DELETE FROM signup WHERE id=?", [id], function(err) {
if (err) throw(err);
res.redirect('back');
console.log("Record Deleted");
});
});
});
});
});
// });
  console.log("Successful");
app.listen(8080, '127.0.0.1');
